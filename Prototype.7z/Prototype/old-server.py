from flask import Flask, session, render_template, request, jsonify, redirect
from flask_session import Session
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from spotipy.oauth2 import SpotifyOAuth
import random
import classes
import json
import os
import uuid
import sys
app = Flask(__name__)

#Session config
app.config['SECRET_KEY'] = os.urandom(64)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = './.flask_session/'
Session(app)

#Spotify Auth for App
SPOTIPY_CLIENT_ID="6bb2a49016654312b66128deef50769a"
SPOTIPY_CLIENT_SECRET="a81c088cdeb14b58a32cf6e5e4bd10b6"

caches_folder = './.spotify_caches/'
if not os.path.exists(caches_folder):
    os.makedirs(caches_folder)

parties = {}

def session_cache_path():
    return caches_folder + session.get('uuid')

def isMaster(partyid, userid):
    return parties[partyid].getMaster() == userid

# Use postman to send request to http://127.0.0.1:5000/closeparty with body in JSON:
#{
#    "userid": 1,
#}
@app.route('/createparty', methods =['POST'])
def createParty():
    if not session.get('uuid'):
        # Step 1. Visitor is unknown, give random ID
        print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", file=sys.stdout)
        session['uuid'] = str(uuid.uuid4())

    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    auth_manager = spotipy.oauth2.SpotifyOAuth(scope='user-read-private user-read-email user-modify-playback-state user-read-playback-position user-library-read streaming user-read-playback-state user-read-recently-played playlist-read-private',
                                                client_id="6bb2a49016654312b66128deef50769a", client_secret="a81c088cdeb14b58a32cf6e5e4bd10b6", cache_handler=cache_handler, show_dialog=True, redirect_uri="http://10.0.2.2:8080/verifiy")
    
    #if request.args.get("code"):
    #    # Step 3. Being redirected from Spotify auth page
    #    auth_manager.get_access_token(request.args.get("code"))
    #    return redirect('/createparty')

    if not auth_manager.validate_token(cache_handler.get_cached_token()):
        # Step 2. Display sign in link when no token
        auth_url = auth_manager.get_authorize_url()
        return jsonify( authUrl=auth_url )
    
    # get POST content
    masterId = request.get_json()['masterid']
    # generate party id
    partyId = random.randint(10000,99999)
    #toDo check if partyId exists in table
    
    # create party instance
    newparty = classes.Party(number,masterid)
    # save party instance
    parties[newparty.getId()] = newparty

    return jsonify( masterid = masterid, partyid = newparty.getId())

# Use postman to send request to http://127.0.0.1:5000/closeparty with body in JSON:
#{
#    "userid": 1,
#    "partyid": 3781
#}
@app.route('/closeparty', methods = ['POST'])
def closeParty():
    # get POST data
    postData = request.get_json()
    userid = postData['userid']
    partyid = postData['partyid']
    # check if party exists
    if partyid not in parties:
        return jsonify( response = "BAD PARTY ID" )
    # check if party master called closeparty
    if isMaster(partyid, userid): 
        del parties[partyid] # delete party
        return jsonify( response = "OK" )
    else:
        return jsonify( response = "NOT A PARTY MASTER" )

# not tested
@app.route('/join', methods = ['POST'])
def join():
    # get POST data
    postData = request.get_json()
    userid = postData['userid']
    partyid = postData['partyid']
    # check if party exists
    if partyid not in parties:
        return jsonify( response = "BAD PARTY ID" )

    if parties[partyid].join(userid):
        return jsonify( response = "JOINED", partyid = partyid, userid = userid) 
    else:
        return jsonify( response = "COULD NOT JOIN THE PARTY")

# not tested
@app.route('/leave', methods = ['POST'])
def leave():
    # get POST data
    postData = request.get_json()
    userid = postData['userid']
    partyid = postData['partyid']
    # check if party exists
    if partyid not in parties:
        return jsonify( response = "BAD PARTY ID" )

    if parties[partyid].leave(userid):
        return jsonify( response = "LEFT", partyid = partyid, userid = userid) 
    else:
        return jsonify( response = "COULD NOT LEAVE THE PARTY")

@app.route('/verifiy', methods = ['GET'])
def verifiy():
    #cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    #auth_manager = spotipy.oauth2.SpotifyOAuth(cache_handler=cache_handler)
    # get POST data
    
    if request.args.get("code"):
        getData = request.args.get("code")
        #auth_manager.get_access_token(request.args.get("code"))
        print("+++++++++++++++++++++++++++++++++++"+getData, file=sys.stdout)
        spotify = spotipy.Spotify(auth="BQDapoXrsK3wdpg1ueVUA7QlIBPkb6gqT_ccXOSUnFG7cAMiTei72mi95uJiLLNUDNWPwwcKBrUCuV9LwixWyMV8u_9DRYYVKVm4Nze-fynsow_jvWgwlNEBR-kvnrtcrxup1ydunyQzfaOGv4uDtAy1ztSv6mxg_p23cMU") 
        spotify.start_playback(uris=['spotify:track:4cOdK2wGLETKBW3PvgPWqT'])
        return f'<p>test</p>'
    if not auth_manager.validate_token(cache_handler.get_cached_token()):
        return f'<p>failed</p>'


if __name__ == '__main__':
    app.run(threaded=True,host='127.0.0.1',port=8080)
from flask import Flask, render_template, request, jsonify
import random
import classes
import json
import sys
import spotipy
import database

app = Flask(__name__)

parties = {}

myDb = database.Database()


# Use postman to send request to http://127.0.0.1:5000/createparty with body in JSON:
#{
#    "userId": "1",
#    "authToken": "ASLDKfmasldkmfaskme2131re3dq3"
#}
@app.route('/createparty', methods =['POST'])
def createParty():
    # get POST content
    masterId = request.get_json()['userId']
    authKey = request.get_json()['authToken']
    # generate party id
    partyId = random.randint(10000,99999)
    while myDb.isPartyIdExist(partyId):
        partyId = random.randint(10000,99999)      
    #we might use hash str in future
    partyId=str(partyId)  
    # create party instance
    newParty = classes.Party(partyId, masterId, authKey)
    # save party instance
    parties[newParty.id] = newParty    
    myDb.saveParty(newParty.id,masterId)
    return jsonify( userId = masterId, partyId = newParty.id)


# Use postman to send request to http://127.0.0.1:5000/closeparty with body in JSON:
#{
#    "userId": "12e11",
#    "partyId": "3781"
#}
@app.route('/closeparty', methods = ['POST'])
def closeParty():
    # get POST data
    postData = request.get_json()
    masterId = postData['userId']
    partyId = postData['partyId']

    #check if thats master who wants to close party
    if(partyId in parties):            
        if parties[partyId].masterId == masterId:
            myDb.setClosingDate(partyId)
            del parties[partyId]            
            return jsonify( response = "SUCCESS: PARTY IS DELETED" )
        else:
            return jsonify ( response = "PARTY ID MATCHED, BUT MASTER ID DOES NOT MATCH ")
    #return jsonify( masterId = masterId, partyId = str(newParty.getId()))
    else:
        return jsonify( response = "PARTY ID DOES NOT MATCH" )
    



#{
#    "userId": "1",
#    "partyId": "3781"
#}
@app.route('/join', methods = ['POST'])
def join():
    # get POST data
    postData = request.get_json()
    userId = postData['userId']
    partyId = postData['partyId']
    # check if party exists
    if partyId not in parties:
        return jsonify( response = "BAD PARTY ID" )

    if parties[partyId].join(userId):
        #maybe return current song
        spotify = spotipy.Spotify(auth=parties[partyId].authKey)
        results = spotify.currently_playing(market='DE')   
        if(results is None):
            return jsonify( response = "JOINED", partyId = partyId, userId = userId, currentMs = "0", song="No Playback") 
        item = results['item']
        currentMs = str(results['progress_ms'])
        durationMs = str(results['duration_ms'])
        song=classes.Song(item['id'],item['name'],item['album']['name'],item['artists'][0]['name'])

        print(parties[partyId].member, file=sys.stdout) 
        return jsonify( response = "JOINED", partyId = partyId, userId = userId, currentMs = currentMs, durationMs=durationMs, song=json.dumps(song.__dict__)) 
    else:
        return jsonify( response = "COULD NOT JOIN THE PARTY")

#{
#    "userId": "1",
#    "partyId": "3781"
#}
@app.route('/leave', methods = ['POST'])
def leave():
    # get POST data
    postData = request.get_json()
    userId = postData['userId']
    partyId = postData['partyId']
    # check if party exists
    if partyId not in parties:
        return jsonify( response = "BAD PARTY ID" )

    if parties[partyId].leave(userId):
        print(parties[partyId].member, file=sys.stdout) 
        return jsonify( response = "LEFT", partyId = partyId, userId = userId) 
    else:
        return jsonify( response = "COULD NOT LEAVE THE PARTY")


# Use postman to send request to http://127.0.0.1:5000/playSong with body in JSON:
#{    
#    "partyId": "3781"
#    "songId" : "232mk3v32K2r3R"
#}
@app.route('/playSong', methods = ['POST'])
def playSong():
    # get POST data
    postData = request.get_json()
    
    songId = postData['songId']
    partyId = postData['partyId']
    
    # check if party exists
    if(partyId in parties):       
        spotify = spotipy.Spotify(auth=parties[partyId].authKey) 
        try:
            spotify.start_playback(uris=['spotify:track:4cOdK2wGLETKBW3PvgPWqT'])#(uris=['spotify:track:'+songId])  
        except:
            return jsonify(response = "Song could not be played.")
        #myDb.saveSong(partyId,) Song object needs to be created or idk
        return jsonify(response = "Success")
    else:     
        return jsonify( response = "BAD PARTY ID" )
    
# Use postman to send request to http://127.0.0.1:5000/searchSong with body in JSON:
#{    
#    "partyId": 3781
#    "searchWord" : "Never gonna let you down"
#}
#returns jsonArray
@app.route('/searchSong', methods = ['POST'])
def searchSong():
    # get POST data
    postData = request.get_json()
    
    searchWord = postData['searchWord']
    partyId = postData['partyId']
    
    # check if party exists
    if(partyId in parties):       
        spotify = spotipy.Spotify(auth=parties[partyId].authKey) 
        results=spotify.search(q=searchWord, limit=5, market='DE')        
        items = results['tracks']['items']
        songs=[]
        if len(items) > 0:
            for i,item in enumerate(items):
                song=classes.Song(item['id'],item['name'],item['album']['name'],item['artists'][0]['name'])
                #songs[i]=json.dumps(song.__dict__)
                songs.append(json.dumps(song.__dict__))
            #print(songs)
            #print(items[0]['id'], file=sys.stdout)
            #print(items[0]['name'], file=sys.stdout)
            #print(items[0]['album']['name'], file=sys.stdout)
            #print(items[0]['artists'][0]['name'], file=sys.stdout)            
            return jsonify(songs)
        else:
            return jsonify(response = "No songs found")
    else:        
        return jsonify( response = "BAD PARTY ID" )        




if __name__ == '__main__':
    app.run()

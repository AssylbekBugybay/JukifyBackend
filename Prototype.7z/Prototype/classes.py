from flask import jsonify

class Party:
    def __init__(self, id, masterId, authKey):
        # constructor
        self.id = id
        self.masterId = masterId
        self.authKey= authKey
        self.member = []
        self.requests = []
    def __del__(self):
        return
    def addMember(self, member):
        self.member.append(member)
    def deleteMember(self, member):
        i = 0
        while (self.member[i].id != member.id and i < len(self.member)):
            i = i+1
        self.member.pop(i)
    def getMember(self):
        return self.member
    def getRequests(self):
        return self.requests
    def getRequest(self):
        if len(self.requests) != 0:
            response = jsonify( 
                spotifyid = self.requests[len(self.requests)-1].getSpotifyId(), 
                name = self.requests[len(self.requests)-1].getName(),
                album = self.requests[len(self.requests)-1].getAlbum(),
                artist = self.requests[len(self.requests)-1].getArtist(),
                amount = len(self.requests)-1
                )
            self.requests.pop(len(self.requests)-1)
            return response
        else:
            return None
    def toString(self):
        return "ID: " + str(self.id) + " |  masterId: " + str(self.masterId)
    def join(self, memberId):
        if memberId not in self.member:
            self.member.append(memberId)
            return True
        else:
            return False
    def leave(self, memberId):
        if memberId == self.masterId:
            return False
        if memberId not in self.member:
            return False
        else:
            self.member.remove(memberId)
            return True
    def addRequest(self, song):
        self.requests.append(song)
    def clearRequests(self):
        self.requests.clear()

        
class Master:
    def __init__(self, id):
        self.id = id
        # constructor
    def getId(self):
        return self.id

class Song:
    def __init__(self, spotifyId, name, album, artist):
        self.spotifyId = spotifyId
        self.name = name
        self.album = album
        self.artist = artist
    def toJSON(self):
        return jsonify(spotifyId = self.spotifyId, name = self.name, album = self.album, artist = self.artist)